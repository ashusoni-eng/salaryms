<?php $__env->startSection('salaries'); ?>
<div class="container-fluid pt-4 px-4">
    <div class="row g-4">
        <div class="col-sm-12 col-xl-12">
            <div class="bg-light rounded h-100 p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h6>Salary List</h6>
                    <button class="btn btn-primary"><a href="<?php echo e(route('salaries.create')); ?>" class="text-white" >Add New</a></button>
                </div>
                <table class="table text-center">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Employee</th>
                            <th scope="col">Month</th>
                            <th scope="col">Year</th>
                            <th scope="col">Total Working Days</th>
                            <th scope="col">Total Leave Taken</th>
                            <th scope="col">Overtime</th>
                            <th scope="col">Salary Made</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $i=1;
                            use Carbon\Carbon;
                        ?>
                        <?php if($salaries): ?>
                            <?php $__currentLoopData = $salaries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($i++); ?></th>
                                    <td><?php echo e($salary->employee->name); ?></td>
                                    <td><?php echo e(Carbon::create()->month($salary->month)->format('F')); ?></td>
                                    <td><?php echo e($salary->year); ?></td>
                                    <td><?php echo e($salary->total_working_days); ?></td>
                                    <td><?php echo e($salary->total_leave_taken); ?></td>
                                    <td><?php echo e($salary->overtime); ?></td>
                                    <td><?php echo e($salary->total_salary_made); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
                <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
                <?php if(session('failed')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session('failed')); ?>

                    </div>
                <?php endif; ?>
                </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\Laravel\salaryms\resources\views/admin/salaries/index.blade.php ENDPATH**/ ?>