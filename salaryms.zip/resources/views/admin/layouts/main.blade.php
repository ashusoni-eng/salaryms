@include('admin.layouts.header')

@yield('dashboard')
@yield('employees')
@yield('salaries')


@include('admin.layouts.footer')